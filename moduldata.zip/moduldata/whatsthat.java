import java.lang.*;
class whatsthat
{
	int num,r=0,s=0;
	whatsthat(int n)
	{
		num = n;
	}
	void Reverse()
	{
		while(num>0)
		{
			r=num%10;
			s=(s*10)+r;
			num=num/10;
		}
		System.out.println("Reverse of number ="+s);
	}
	public static void main(String args[])
	{
		whatsthat r1 = new whatsthat(786*786);
		r1.Reverse();
	}
}
